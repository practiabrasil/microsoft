# Localization
The App currently supports the below locales.

1. ar-SA
2. de-DE
3. en-US
4. es-ES
5. fr-FR
6. he-IL
7. ja-JP
8. ko-KR
9. pt-BR
10. ru-RU
11. zh-CN
12. zh-TW  
  
You can find the translations in `Source/CompanyCommunicator/ClientApp/public/locales` and
the resource strings can be found in `Source/CompanyCommunicator.Common/Resources`.

**NOTE:** You can add/update the resources for other locales and update the configuration.