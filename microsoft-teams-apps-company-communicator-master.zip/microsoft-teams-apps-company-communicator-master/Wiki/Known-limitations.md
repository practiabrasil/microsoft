# Known Limitations
## 1. Author/publishing experience is not supported on Mobile

The tab where authors/creators of messages create a message is currently not supported on mobile. The recommended approach is to create the messages on desktop only.

## 2. Adaptive card doesn't support RTL

The app supports localization. Only the adaptive card currently doesn't support RTL.